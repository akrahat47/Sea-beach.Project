#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>
#include <math.h>
#define PI 3.14159265358979323846


bool isDay = true;   // true = Day, false = Night
GLfloat waveOffset1 = 0.0f;
GLfloat waveOffset2 = 1.5f;
GLfloat waveOffset3 = 3.0f;

void keyboard(unsigned char key, int x, int y)
{
    if (key == 'd' || key == 'D')
    {
        isDay = true;
    }
    else if (key == 'n' || key == 'N')
    {
        isDay = false;
    }
    glutPostRedisplay();
}


void sound()
{
    // This will play the WAV file asynchronously and loop forever
    PlaySound("sound.wav", NULL, SND_ASYNC | SND_FILENAME | SND_LOOP);
}



void renderBitmapString(float x, float y, float z, void *font, const char *string)
{
    const char *c;
    glRasterPos3f(x, y, z);
    for (c = string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}



GLfloat position1 = 0.0f;
GLfloat speed1 = 0.08f;

void update1(int value)
{
    if (position1 > 1.6f)
        position1 = 0.0f;

    position1 += speed1;

    glutPostRedisplay();
    glutTimerFunc(500, update1, 0);

}

void updateWave(int value)
{
    waveOffset1 += 0.05f;
    waveOffset2 += 0.04f;
    waveOffset3 += 0.03f;

    if (waveOffset1 > 2 * PI) waveOffset1 = 0;
    if (waveOffset2 > 2 * PI) waveOffset2 = 0;
    if (waveOffset3 > 2 * PI) waveOffset3 = 0;

    glutPostRedisplay();
    glutTimerFunc(50, updateWave, 0);
}


void drawSeaWaves()
{
    float x;
    glLineWidth(2.0f);

    // 🌊 Wave 1 (near)
    if (isDay) glColor3f(0.8f, 0.9f, 1.0f);
    else       glColor3f(0.6f, 0.6f, 0.9f);

    glBegin(GL_LINE_STRIP);
    for (x = -1.0f; x <= 1.0f; x += 0.02f)
        glVertex2f(x, -0.30f + 0.025f * sin(6 * x + waveOffset1));
    glEnd();

    // 🌊 Wave 2 (middle)
    if (isDay) glColor3f(0.7f, 0.85f, 1.0f);
    else       glColor3f(0.5f, 0.5f, 0.85f);

    glBegin(GL_LINE_STRIP);
    for (x = -1.0f; x <= 1.0f; x += 0.02f)
        glVertex2f(x, -0.40f + 0.020f * sin(5 * x + waveOffset2));
    glEnd();

    // 🌊 Wave 3 (far)
    if (isDay) glColor3f(0.6f, 0.8f, 0.95f);
    else       glColor3f(0.4f, 0.4f, 0.75f);

    glBegin(GL_LINE_STRIP);
    for (x = -1.0f; x <= 1.0f; x += 0.02f)
        glVertex2f(x, -0.50f + 0.015f * sin(4 * x + waveOffset3));
    glEnd();
}



void drawStars()
{
    glPointSize(2.0f);
    glColor3f(1.0f, 1.0f, 1.0f); // white stars

    glBegin(GL_POINTS);

    // Random-like fixed star positions
    glVertex2f(-0.90f, 0.90f);
    glVertex2f(-0.70f, 0.85f);
    glVertex2f(-0.50f, 0.95f);
    glVertex2f(-0.30f, 0.88f);
    glVertex2f(-0.10f, 0.92f);
    glVertex2f( 0.10f, 0.87f);
    glVertex2f( 0.30f, 0.93f);
    glVertex2f( 0.50f, 0.89f);
    glVertex2f( 0.70f, 0.94f);
    glVertex2f( 0.90f, 0.86f);

    glVertex2f(-0.80f, 0.75f);
    glVertex2f(-0.60f, 0.78f);
    glVertex2f(-0.40f, 0.72f);
    glVertex2f(-0.20f, 0.80f);
    glVertex2f( 0.00f, 0.76f);
    glVertex2f( 0.20f, 0.82f);
    glVertex2f( 0.40f, 0.74f);
    glVertex2f( 0.60f, 0.79f);
    glVertex2f( 0.80f, 0.73f);

    glEnd();
}
/////// STONES ///////

void drawStone(float x, float y, float r)
{
    int i;
    int triangleAmount = 40;
    GLfloat twicePi = 2.0f * PI;

    glColor3f(0.45f, 0.45f, 0.45f); // stone color

    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        for (i = 0; i <= triangleAmount; i++)
        {
            glVertex2f(
                x + (r * cos(i * twicePi / triangleAmount)),
                y + (r * sin(i * twicePi / triangleAmount))
            );
        }
    glEnd();
}



void display()

{

   glClearColor(1.0f, 1.0f, 1.0f, 1.0f);


    glClear(GL_COLOR_BUFFER_BIT);

    glPointSize(10);

/////////SKY/////////
if (isDay)
    glColor3f(0.53f, 0.81f, 0.92f);   // Day sky
else
    glColor3f(0.05f, 0.05f, 0.20f);   // Night sky


glBegin(GL_QUADS);

    glVertex2f(-1.00f,  1.00f);
    glVertex2f(-1.00f,  0.20f);
    glVertex2f( 1.00f,  0.20f);
    glVertex2f( 1.00f,  1.00f);
    glEnd();
if (!isDay)
{
    drawStars();
}

//////LOW CLOUD//////

  {
int i;

	GLfloat x=-0.88f; GLfloat y=0.24f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x=-0.76f; GLfloat y=0.20f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x=-0.84f; GLfloat y=0.36f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x=-0.64f; GLfloat y=0.28f; GLfloat radius =0.12f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x=-0.48f; GLfloat y=0.36f; GLfloat radius =0.17f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x=-0.20f; GLfloat y=0.40f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x=-0.00f; GLfloat y=0.30f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x= 0.20f; GLfloat y=0.24f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x= 0.44f; GLfloat y=0.24f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x= 0.68f; GLfloat y=0.32f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x= 0.84f; GLfloat y=0.20f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

{
int i;

	GLfloat x= 0.96f; GLfloat y=0.12f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}


///SUN////
{
int i;

	GLfloat x=-0.60f; GLfloat y=0.80f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

if (isDay)
{
    glColor3f(1.00f, 0.90f, 0.20f);   // Sun
}
else
{
    glColor3f(0.90f, 0.90f, 0.95f);   // Moon
}


	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

//////////SEA//////////

if (isDay)
    glColor3f(0.10f, 0.45f, 0.60f);   // Day sea
else
    glColor3f(0.02f, 0.10f, 0.20f);   // Night sea


glBegin(GL_QUADS);

    glVertex2f(-1.0f,  0.20f);
    glVertex2f(-1.0f, -0.80f);
    glVertex2f(1.00f, -0.80f);
    glVertex2f(1.00f,  0.20f);
    glEnd();

    glLineWidth(5.0f);

    // 🌊 Waves////

drawSeaWaves();

//////////SHIP//////////

glPushMatrix();
glTranslatef(position1, 0.0f, 0.0f);

glColor3f(0.6f, 0.0f, 0.0f);

glBegin(GL_QUADS);

    glVertex2f(-0.88f, -0.28f);
    glVertex2f(-0.80f, -0.40f);
    glVertex2f(-0.48f, -0.40f);
    glVertex2f(-0.40f, -0.28f);
    glEnd();

glColor3f(0.0f, 0.4f, 0.0f);

glBegin(GL_QUADS);

    glVertex2f(-0.80f,-0.16f);
    glVertex2f(-0.80f,-0.28f);
    glVertex2f(-0.48f,-0.28f);
    glVertex2f(-0.48f,-0.16f);
    glEnd();

glColor3f(0.6f, 0.0f, 0.0f);

glBegin(GL_QUADS);

    glVertex2f(-0.76f,-0.20f);
    glVertex2f(-0.76f,-0.24f);
    glVertex2f(-0.68f,-0.24f);
    glVertex2f(-0.68f,-0.20f);
    glEnd();

glColor3f(0.6f, 0.0f, 0.0f);

glBegin(GL_QUADS);

    glVertex2f(-0.62f,-0.20f);
    glVertex2f(-0.62f,-0.24f);
    glVertex2f(-0.53f,-0.24f);
    glVertex2f(-0.53f,-0.20f);
    glEnd();

glColor3f(0.3f, 0.15f, 0.05f);

glBegin(GL_QUADS);

    glVertex2f(-0.76f,-0.08f);
    glVertex2f(-0.76f,-0.16f);
    glVertex2f(-0.68f,-0.16f);
    glVertex2f(-0.68f,-0.08f);
    glEnd();

glColor3f(0.3f, 0.15f, 0.05f);

glBegin(GL_QUADS);

    glVertex2f(-0.60f,-0.08f);
    glVertex2f(-0.60f,-0.16f);
    glVertex2f(-0.52f,-0.16f);
    glVertex2f(-0.52f,-0.08f);
    glEnd();

//////MOVE CLOUD1//////

  {
int i;

	GLfloat x=-0.60f; GLfloat y=0.72f; GLfloat radius =0.07f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

//////MOVE CLOUD2//////

  {
int i;

	GLfloat x=-0.52f; GLfloat y=0.72f; GLfloat radius =0.07f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

//////MOVE CLOUD3//////

  {
int i;

	GLfloat x=-0.68f; GLfloat y=0.72f; GLfloat radius =0.07f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

//////MOVE CLOUD4//////

  {
int i;

	GLfloat x=-0.08f; GLfloat y=0.72f; GLfloat radius =0.07f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

//////MOVE CLOUD5//////

  {
int i;

	GLfloat x=0.00f; GLfloat y=0.72f; GLfloat radius =0.07f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

//////MOVE CLOUD6//////

  {
int i;

	GLfloat x=0.08f; GLfloat y=0.72f; GLfloat radius =0.07f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

glPopMatrix();




///////////SAND////////////

glColor3f(0.0f, 0.0f, 0.0f);

glBegin(GL_LINES);

        glVertex2f(-1.00f, -0.60f);
        glVertex2f(-0.72f, -0.52f);

        glVertex2f(-0.72f, -0.52f);
        glVertex2f(-0.60f, -0.52f);

        glVertex2f(-0.60f, -0.52f);
        glVertex2f(-0.40f, -0.60f);

        glVertex2f(-0.40f, -0.60f);
        glVertex2f(-0.44f, -0.68f);

        glVertex2f(-0.44f, -0.68f);
        glVertex2f(-0.20f, -0.72f);

        glVertex2f(-0.20f, -0.72f);
        glVertex2f( 0.00f, -0.72f);

        glVertex2f( 0.00f, -0.72f);
        glVertex2f( 0.32f, -0.64f);

        glVertex2f( 0.32f, -0.64f);
        glVertex2f( 0.44f, -0.64f);

        glVertex2f( 0.44f, -0.64f);
        glVertex2f( 0.60f, -0.60f);

        glVertex2f( 0.60f, -0.60f);
        glVertex2f( 0.80f, -0.56f);

        glVertex2f( 0.80f, -0.56f);
        glVertex2f( 0.92f, -0.52f);

        glVertex2f( 0.92f, -0.52f);
        glVertex2f( 1.00f, -0.56f);

    glEnd ();

 glColor3f(0.85f, 0.72f, 0.42f);

glBegin(GL_QUADS);

    glVertex2f(-1.00f, -0.60f);
    glVertex2f(-1.00f, -1.00f);
    glVertex2f(-0.72f, -1.00f);
    glVertex2f(-0.72f,- 0.52f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f(-0.72f, -0.52f);
    glVertex2f(-0.72f, -1.00f);
    glVertex2f(-0.60f, -1.00f);
    glVertex2f(-0.60f, -0.52f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f(-0.60f, -0.52f);
    glVertex2f(-0.60f, -1.00f);
    glVertex2f(-0.44f, -0.68f);
    glVertex2f(-0.40f, -0.60f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f(-0.44f, -0.68f);
    glVertex2f(-0.72f, -1.00f);
    glVertex2f(-0.20f, -1.00f);
    glVertex2f(-0.20f, -0.72f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f(-1.00f, -0.60f);
    glVertex2f(-1.00f, -1.00f);
    glVertex2f(-0.72f, -1.00f);
    glVertex2f(-0.72f,- 0.52f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f(-0.20f, -0.72f);
    glVertex2f(-0.20f, -1.00f);
    glVertex2f( 0.00f, -1.00f);
    glVertex2f( 0.00f, -0.72f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f( 0.00f, -0.72f);
    glVertex2f( 0.00f, -1.00f);
    glVertex2f( 0.32f, -1.00f);
    glVertex2f( 0.32f, -0.64f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f( 0.32f, -0.64f);
    glVertex2f( 0.32f, -1.00f);
    glVertex2f( 0.44f, -1.00f);
    glVertex2f( 0.44f, -0.64f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f( 0.44f, -0.64f);
    glVertex2f( 0.44f, -1.00f);
    glVertex2f( 0.60f, -1.00f);
    glVertex2f( 0.60f, -0.60f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f( 0.60f, -0.60f);
    glVertex2f( 0.60f, -1.00f);
    glVertex2f( 0.80f, -1.00f);
    glVertex2f( 0.80f, -0.56f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f( 0.80f, -0.56f);
    glVertex2f( 0.80f, -1.00f);
    glVertex2f( 0.92f, -1.00f);
    glVertex2f( 0.92f, -0.52f);
    glEnd();

glBegin(GL_QUADS);

    glVertex2f( 0.92f, -0.52f);
    glVertex2f( 0.92f, -1.00f);
    glVertex2f( 1.00f, -1.00f);
    glVertex2f( 1.00f, -0.56f);
    glEnd();

//////TREE/////////

glColor3f(0.59f, 0.29f, 0.00f);

glBegin(GL_QUADS);

    glVertex2f( 0.60f, -0.52f);
    glVertex2f( 0.60f, -1.00f);
    glVertex2f( 0.64f, -1.00f);
    glVertex2f( 0.64f, -0.52f);
    glEnd();

glColor3f(0.0f, 0.0f, 0.00f);

glBegin(GL_LINES);

        glVertex2f(0.60f, -0.75f);
        glVertex2f(0.64f, -0.75f);

        glVertex2f(0.60f, -0.60f);
        glVertex2f(0.64f, -0.60f);

        glVertex2f(0.60f, -0.90f);
        glVertex2f(0.64f, -0.90f);

glEnd ();

////// SAND ///////
glColor3f(0.85f, 0.72f, 0.42f);


////// STONES ON SAND ///////
drawStone(-0.85f, -0.85f, 0.03f);
drawStone(-0.75f, -0.88f, 0.02f);
drawStone(-0.65f, -0.82f, 0.025f);
drawStone(-0.30f, -0.90f, 0.03f);
drawStone(-0.20f, -0.85f, 0.02f);
drawStone(0.10f, -0.88f, 0.03f);
drawStone(0.25f, -0.92f, 0.02f);
drawStone(0.55f, -0.86f, 0.03f);
drawStone(0.70f, -0.90f, 0.02f);



////TREE1////
{
int i;

	GLfloat x=0.52f; GLfloat y=-0.56f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

////TREE2////
{
int i;

	GLfloat x=0.52f; GLfloat y=-0.48f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

////TREE3////
{
int i;

	GLfloat x=0.60f; GLfloat y=-0.36f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

////TREE4////
{
int i;

	GLfloat x=0.68f; GLfloat y=-0.44f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

////TREE5////
{
int i;

	GLfloat x=0.72f; GLfloat y=-0.56f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}


glColor3f(0.59f, 0.29f, 0.00f);

glBegin(GL_QUADS);

    glVertex2f( 0.88f, -0.44f);
    glVertex2f( 0.88f, -1.00f);
    glVertex2f( 0.92f, -1.00f);
    glVertex2f( 0.92f, -0.44f);
    glEnd();

glColor3f(0.0f, 0.0f, 0.00f);

glBegin(GL_LINES);

        glVertex2f(0.88f, -0.75f);
        glVertex2f(0.92f, -0.75f);

        glVertex2f(0.88f, -0.60f);
        glVertex2f(0.92f, -0.60f);

        glVertex2f(0.88f, -0.90f);
        glVertex2f(0.92f, -0.90f);

glEnd ();

////TREE6////
{
int i;

	GLfloat x=0.84f; GLfloat y=-0.58f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

////TREE7////
{
int i;

	GLfloat x=0.80f; GLfloat y=-0.44f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

///TREE8////
{
int i;

	GLfloat x=0.86f; GLfloat y=-0.36f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

///TREE9////
{
int i;

	GLfloat x=1.00f; GLfloat y=-0.44f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

///TREE10////
{
int i;

	GLfloat x=1.00f; GLfloat y=-0.52f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

//////GRASS///////

///GRASS1////
{
int i;

	GLfloat x=-0.92f; GLfloat y=-0.92f; GLfloat radius =0.13f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

///GRASS2////
{
int i;

	GLfloat x=-0.76f; GLfloat y=-0.90f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

///GRASS3////
{
int i;

	GLfloat x=-0.66f; GLfloat y=-0.98f; GLfloat radius =0.07f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

///GRASS4////
{
int i;

	GLfloat x=-0.50f; GLfloat y=-0.98f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.05f, 0.25f, 0.05f);

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
}

///////MOUNTAIN//////

glColor3f(0.40f, 0.40f, 0.40f);

glBegin(GL_TRIANGLES);

    glVertex2f( 0.08f,  0.40f);
    glVertex2f(-0.24f,  0.20f);
    glVertex2f( 0.00f,  0.20f);
    glEnd();

glColor3f(0.55f, 0.55f, 0.55f);

glBegin(GL_TRIANGLES);

    glVertex2f(0.08f, 0.40f);
    glVertex2f(0.00f, 0.20f);
    glVertex2f(0.32f, 0.20f);
    glEnd();

glColor3f(0.55f, 0.55f, 0.55f);

glBegin(GL_TRIANGLES);

    glVertex2f(-0.28f, 0.40f);
    glVertex2f(-0.36f, 0.20f);
    glVertex2f(-0.12f, 0.20f);
    glEnd();

glColor3f(0.40f, 0.40f, 0.40f);

glBegin(GL_TRIANGLES);

    glVertex2f(-0.28f, 0.40f);
    glVertex2f(-0.52f, 0.20f);
    glVertex2f(-0.36f, 0.20f);
    glEnd();

    glFlush();
}
void mouse(int button, int state, int x, int y)
{
    if (state == GLUT_DOWN)
    {
        if (button == GLUT_LEFT_BUTTON)
        {
            speed1 = 0.20f;   // 🚀 Fast speed
        }
        else if (button == GLUT_RIGHT_BUTTON)
        {
            speed1 = 0.04f;   // 🐢 Slow speed
        }
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    // FIX: Required for drawing
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);

    glutInitWindowSize(640, 480);
    glutInitWindowPosition(80, 50);
    glutCreateWindow("Ctg Sea Beach");
glutKeyboardFunc(keyboard);
glutTimerFunc(50, updateWave, 0);
glutMouseFunc(mouse);

    glutDisplayFunc(display);
    glutTimerFunc(100, update1, 0);
sound();
    glutMainLoop();

    return 0;
}
